﻿using FeedbackApp.Models.DTOs;

namespace FeedbackApp.Interfaces
{
    public interface IUserService
    {
        UserDTO Login(UserDTO userDTO);
        UserDTO Register(UserDTO userDTO);
    }
}
