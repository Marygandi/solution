﻿using FeedbackApp.Models.DTOs;

namespace FeedbackApp.Interfaces
{
    public interface ITokenService
    {
        string GetToken(UserDTO user);
    }
}